# CPTR 142: Project #2
## Student: Raven Chester
------
## Notes
* Need to add testing 
* Need to have separate functions in their own files
* Program does not run


## Solution Checklist
* Program divided into well-defined and logical sub-tasks:✔
* Logical function groups in separate files: ❌
    * Main program separate from supporting functions: ❌
* File that tests supporting functions: ❌
* If using class, each class saved in separate files: ✔
* Program contains at least three files: ❌
    * The main program: ✔
    * Supporting functions: ❌
    * Testing for the supporting functions: ❌
* Converted program runs as expected: ❌
* Includes program that is being converted: ❌

Answer these questions in the `REPORT.md` file.
* Describe original program: ✔
* What files are part of the original solutions: ✔
* What files are part of your converted solutions: ✔
* What challenges did you have converting your program: ✔
* What language was better suited for the task? Explain why: ✔
---
## GRADE 
* Graded on 2-20-2023, R