Q) Original Program?

A) The original was a c++ program that functions as a multiplication calculator that implements the Ancient Egyptian method of multiplication.


Q) What files were part of the original solution?

A) The original solution only has the main program. All the code is all in one place.


Q) What files are part of your converted solutions?

A.) So far, only a main body script for the program. It's still in progress, but I plan to make mutiple files such as classes or functions, as well as a test file to 
    shorten the amount of code of one file.

Q) What challenges do you have converting the program?

A.) Syntax difference. Some functions easily usable in C++ may not be in Python, so finding workarounds can sometimes be hard or just time consuming.


Q). What language was better suited for the task?

A.) I believe C++ is better for the task. You have more control of what you instantiate, and for me, that's easier to interpret as compared to stuff like classes.
    I think that's just a byproduct of me learning C++ first though. Plus having access to Do-While loops is perfect for this type of program.